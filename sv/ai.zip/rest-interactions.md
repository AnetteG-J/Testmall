# REST-interaktioner och sökparametrar - Inera FHIR Implementation Guide Template v2.3.0

## REST-interaktioner och sökparametrar

**Beskriv vilka REST-interaktioner (read, search, create, update, …) varje roll ska stödja, för vilka resurser/profiler. Lista de sökparametrar som stöds per resurs, inklusive eventuella kombinationer som ska stödjas.**

| | | |
| :--- | :--- | :--- |
| **[Profilnamn]** | **[t.ex. search, read]** | **[t.ex. `patient`, `date`]** |

-------

> **Vägledning för författare:** Roller och deras verksamhetsansvar beskrivs under [Roller och ansvar](roles-and-responsibilities.md) (Funktionellt). Håll denna sida på ett konkret, tekniskt REST-plan.

